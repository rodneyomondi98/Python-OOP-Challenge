from pet import Pet

def main():
    # Create a pet object
    my_pet = Pet("Buddy")
    
    # Test initial status
    my_pet.get_status()
    
    # Test core methods
    my_pet.eat()
    my_pet.sleep()
    my_pet.play()
    my_pet.get_status()
    
    # Test bonus methods
    my_pet.train("Sit")
    my_pet.train("Roll Over")
    my_pet.train("Sit")  # Test duplicate trick
    my_pet.show_tricks()

if __name__ == "__main__":
    main()